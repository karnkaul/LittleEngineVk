#pragma once

namespace capo {
///
/// \brief A 3D vector.
///
struct Vec3 {
	float x{};
	float y{};
	float z{};
};
} // namespace capo
