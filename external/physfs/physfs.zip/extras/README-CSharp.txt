There used to be C# bindings in this directory, but they have been
unmaintained for many years.

Instead, there is a more modern PhysicsFS wrapper for .NET available.

You can find it at https://github.com/frabert/SharpPhysFS

Thanks to Francesco Bertolaccini for his efforts on that project!

--ryan.

